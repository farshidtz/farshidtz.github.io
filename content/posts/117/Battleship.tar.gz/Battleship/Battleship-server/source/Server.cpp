/******************************************************************* 
TDP3471 - Distributed and Parallel Computing
Farshid Tavakolizadeh
Email: email@farshid.ws
Project Page: https://farshid.ws/projects.php?id=117
Some copyrights goes to Dave Smith (chatterbox.zip)
Year: 2012
********************************************************************/

#include "Server.h"

#include <QTcpSocket>
#include <QRegExp>

ChatterBoxServer::ChatterBoxServer(QObject *parent) : QTcpServer(parent)
{
}

void ChatterBoxServer::incomingConnection(int socketfd)
{
    QTcpSocket *client = new QTcpSocket(this);
    client->setSocketDescriptor(socketfd);
    clients.insert(client);

    qDebug() << "New client from:" << client->peerAddress().toString();

    connect(client, SIGNAL(readyRead()), this, SLOT(readyRead()));
    connect(client, SIGNAL(disconnected()), this, SLOT(disconnected()));
}

void ChatterBoxServer::readyRead()
{
    QTcpSocket *client = (QTcpSocket*)sender();
    while(client->canReadLine())
    {
        QString line = QString::fromUtf8(client->readLine()).trimmed();
        qDebug() << "Read line:" << line;

        QRegExp meRegex("^/me:(.*)$");
        QRegExp targetRegex("^/target:(.*)$");
        QRegExp resultRegex("^/result:(.*)$");

        if(meRegex.indexIn(line) != -1)
        {
            QString user = meRegex.cap(1);
            users[client] = user;
            foreach(QTcpSocket *client, clients)
                client->write(QString("<i> Server:" + user + " has joined.</i>\n").toUtf8());
            sendUserList();
        }
        else if(targetRegex.indexIn(line) != -1)
        {
            QString target = targetRegex.cap(1);

            QString user = users[client];
            qDebug() << "User:" << user;
            qDebug() << "Target:" << target;

            foreach(QTcpSocket *otherClient, clients)
                otherClient->write(QString(user + "->" + target + "\n").toUtf8());
        }
        else if(resultRegex.indexIn(line) != -1)
        {
            QString result = resultRegex.cap(1);

            QString user = users[client];
            qDebug() << "User:" << user;
            qDebug() << "Result:" << result;

            foreach(QTcpSocket *otherClient, clients)
                otherClient->write(QString(user + "<-" + result + "\n").toUtf8());
        }
        else if(users.contains(client))
        {
            QString message = line;
            QString user = users[client];
            qDebug() << "User:" << user;
            qDebug() << "Message:" << message;

            foreach(QTcpSocket *otherClient, clients)
                otherClient->write(QString(user + ":" + message + "\n").toUtf8());
        }
        else
        {
            qWarning() << "Got bad message from client:" << client->peerAddress().toString() << line;
        }
    }
}

void ChatterBoxServer::disconnected()
{
    QTcpSocket *client = (QTcpSocket*)sender();
    qDebug() << "Client disconnected:" << client->peerAddress().toString();

    clients.remove(client);

    QString user = users[client];
    users.remove(client);

    sendUserList();
    foreach(QTcpSocket *client, clients)
        client->write(QString("Server:" + user + " has left.\n").toUtf8());
}

void ChatterBoxServer::sendUserList()
{
    QStringList userList;
    foreach(QString user, users.values())
        userList << user;

    foreach(QTcpSocket *client, clients)
        client->write(QString("/users:" + userList.join(",") + "\n").toUtf8());
}
